


public class Test  
{
	public static void main(String [] args)  
	{
		int a = 10;
		int n = 10;
		if (a == n)   
		{
			System.out.println("hello world");
		}
	}
}