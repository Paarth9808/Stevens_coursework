//Paarth Badola
// 20012789

public interface Colorable {
	
	String howToColor();
	
}
